"use client";

import { calculateTradeQuality } from "@/lib/tradeQuality";

type Trade = {
  id?: number;
  pnl?: number;
  risk?: number;
  ruleFollowed?: string;
  emotion?: string;
  planned?: boolean;
};

export default function TradeQualityCard({
  trade,
}: {
  trade: Trade;
}) {
  const report = calculateTradeQuality(trade);

  return (
    <section className="rounded-2xl border border-slate-800 bg-slate-900 p-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold">
            Trade Quality Score
          </h2>

          <p className="mt-1 text-sm text-slate-400">
            AI evaluation of execution quality.
          </p>
        </div>

        <div className="text-right">
          <div className="text-4xl font-bold text-yellow-400">
            {report.score}
          </div>

          <div className="text-xs text-slate-400">
            /100
          </div>
        </div>
      </div>

      <div className="mt-6 grid gap-6 md:grid-cols-2">
        <div>
          <h3 className="mb-3 font-semibold text-emerald-400">
            Strengths
          </h3>

          <ul className="space-y-2 text-sm text-slate-300">
            {report.strengths.length === 0 ? (
              <li>No strengths detected.</li>
            ) : (
              report.strengths.map((item, index) => (
                <li key={index}>✅ {item}</li>
              ))
            )}
          </ul>
        </div>

        <div>
          <h3 className="mb-3 font-semibold text-red-400">
            Weaknesses
          </h3>

          <ul className="space-y-2 text-sm text-slate-300">
            {report.weaknesses.length === 0 ? (
              <li>No weaknesses detected.</li>
            ) : (
              report.weaknesses.map((item, index) => (
                <li key={index}>❌ {item}</li>
              ))
            )}
          </ul>
        </div>
      </div>
    </section>
  );
}