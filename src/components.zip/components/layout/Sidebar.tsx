"use client";

import {
    LayoutDashboard,
    Brain,
    Calendar,
    Database,
    BarChart3,
    Settings,
    CandlestickChart,
    Bell
} from "lucide-react";

const items=[
["Dashboard",LayoutDashboard],
["Live Intelligence",Brain],
["FOMC",Calendar],
["Core CPI",Bell],
["NFP",CandlestickChart],
["Historical",Database],
["Pattern AI",BarChart3],
["Settings",Settings]
];

export default function Sidebar(){

return(

<div className="w-72 h-screen bg-[#101722] border-r border-[#1f2937]">

<div className="text-3xl font-bold text-[#E8B54A] p-8">
EDGE X PRO
</div>

<div className="space-y-2 px-4">

{items.map(([name,Icon])=>{

const I=Icon as any;

return(

<button
key={name as string}
className="flex items-center gap-4 w-full rounded-xl px-4 py-4 text-left hover:bg-[#182333] transition">

<I size={20}/>

{name}

</button>

);

})}

</div>

</div>

);

}